<h1>Test URL</h1>
url(): {{ $request->url() }}<br>
fullUrl(): {{ $request->fullUrl() }}<br>
fullUrlWithQuery(type=phone): {{ $request->fullUrlWithQuery(['type' => 'phone']) }}
