<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TP Laravel - Manipulation des Requêtes HTTP</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            margin: 0;
            color: white;
        }

        .container {
            max-width: 1100px;
            margin: 0 auto;
            padding: 2rem;
        }

        header {
            text-align: center;
            padding: 4rem 0 2rem;
            position: relative;
        }

        h1 {
            font-size: 4.5rem;
            font-weight: 800;
            background: linear-gradient(to right, #667eea, #f368e0);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin: 0;
        }

        h2 {
            color: #f368e0;
            font-size: 2.8rem;
            margin: 3rem 0 1.5rem;
        }

        .subtitle {
            font-size: 2rem;
            opacity: 0.9;
            margin-top: 1rem;
        }

        .card {
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 2rem;
            margin: 1.5rem 0;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
            transition: transform 0.3s;
        }

        .card:hover {
            transform: translateY(-10px);
        }

        ul {
            list-style: none;
            padding: 0;
        }

        li {
            margin: 1rem 0;
            font-size: 1.2rem;
        }

        a {
            color: #fff;
            text-decoration: none;
            padding: 0.8rem 1.5rem;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 50px;
            display: inline-block;
            transition: all 0.3s;
            font-weight: 600;
        }

        a:hover {
            background: #f368e0;
            transform: scale(1.05);
        }

        .badge {
            background: #f368e0;
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            font-size: 0.8rem;
            margin-left: 10px;
        }

        .shapes {
            position: absolute;
            pointer-events: none;
            z-index: -1;
        }

        .circle {
            width: 300px;
            height: 300px;
            background: rgba(243, 104, 224, 0.3);
            border-radius: 50%;
            position: absolute;
            top: -100px;
            right: -100px;
        }

        .bar {
            width: 500px;
            height: 150px;
            background: linear-gradient(45deg, #667eea, #764ba2);
            border-radius: 100px;
            position: absolute;
            transform: rotate(30deg);
        }

        .bar1 {
            top: 100px;
            left: -200px;
        }

        .bar2 {
            bottom: 100px;
            right: -150px;
            transform: rotate(-45deg);
        }
    </style>
</head>

<body>
    <div class="shapes">
        <div class="circle"></div>
        <div class="bar bar1"></div>
        <div class="bar bar2"></div>
    </div>

    <div class="container">
        <header>
            <h1>Manipulation<br>des Requêtes<br>HTTP</h1>
            <p class="subtitle">TP Complet • Laravel • Illuminate\Http\Request</p>
        </header>

        <div class="card">
            <h2>Vue d'ensemble (Tout en un)</h2>
            <ul>
                <li>
                    <a href="{{ url('/test/request?name=Ahmed&age=25&active=1&birthday=1995-03-20') }}">
                        Voir TOUTES les méthodes en action (JSON complet)
                    </a>
                    <span class="badge">Recommandé</span>
                </li>
            </ul>
        </div>

        <div class="card">
            <h2>Tests par fonctionnalité</h2>
            <ul>
                <li><a href="{{ url('/test/path') }}">Chemin & Route → path(), is(), routeIs()</a></li>
                <li><a href="{{ url('/admin/users') }}">Route admin → routeIs('admin.*')</a></li>
                <li><a href="{{ url('/test/url?type=phone&category=smart') }}">URL complète → url(), fullUrl(),
                        fullUrlWithQuery()</a></li>
                <li><a href="{{ url('/test/method') }}">Méthode HTTP → method(), isMethod()</a></li>
                <li><a href="{{ url('/test/input') }}" target="_blank">Formulaire → Input, boolean, date,
                        only/except...</a></li>
                <li><a href="{{ url('/test/old-input') }}">Old Input + Flash Data</a></li>
                <li><a href="{{ url('/test/cookie') }}">Cookies → lecture & création</a></li>
                <li><a href="{{ url('/test/upload') }}" target="_blank">Formulaire de telechargement</a></li>
            </ul>
        </div>

        <div class="card">
            <h2>Conseils d'utilisation</h2>
            <ul>
                <li>Ouvre les liens dans de nouveaux onglets</li>
                <li>Utilise Postman pour tester les headers (Bearer Token, Accept, etc.)</li>
                <li>La page <strong>/test/request</strong> montre absolument tout d’un coup !</li>
            </ul>
        </div>

    </div>
</body>

</html>
