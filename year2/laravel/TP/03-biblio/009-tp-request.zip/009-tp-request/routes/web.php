<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\RequestTestController;
use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken;

Route::get('/', [RequestTestController::class, 'home'])->name('home');
Route::get('/test/request', [RequestTestController::class, 'showAllMethods']);

// Routes spécifiques pour tester chaque fonctionnalité
Route::get('/test/path', [RequestTestController::class, 'testPath']);
Route::get('/admin/users', [RequestTestController::class, 'testIsAdmin'])->name('admin.users');
Route::get('/test/url', [RequestTestController::class, 'testUrl']);
Route::any('/test/method', [RequestTestController::class, 'testMethod'])->withoutMiddleware(VerifyCsrfToken::class);
Route::get('/test/input', [RequestTestController::class, 'testInput']);
Route::get('/test/old-input', [RequestTestController::class, 'testOldInputForm']);
Route::post('/test/old-input', [RequestTestController::class, 'testOldInputPost']);
Route::get('/test/cookie', [RequestTestController::class, 'testCookie']);

// TP upload de fichier
Route::get('/test/upload', [RequestTestController::class, 'uploadform']);
Route::post('/test/upload', [RequestTestController::class, 'storefile'])->name('upload.file');
Route::get('/test/upload-success', [RequestTestController::class, 'uploadSuccess'])->name('upload.success');
// route to download file
Route::get('/test/download/{filename}', [RequestTestController::class, 'downloadFile'])->name('download.file')->where('filename', '.*');;
