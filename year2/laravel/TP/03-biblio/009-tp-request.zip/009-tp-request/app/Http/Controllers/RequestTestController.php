<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class RequestTestController extends Controller
{
    public function home()
    {
        return view('home');
    }

    public function showAllMethods(Request $request)
    {
        return response()->json([
            'path' => $request->path(),
            'is_admin_route' => $request->is('admin/*'),
            'route_is_admin' => $request->routeIs('admin.*'),
            'url' => $request->url(),
            'fullUrl' => $request->fullUrl(),
            'fullUrlWithQuery' => $request->fullUrlWithQuery(['test' => 'valeur']),
            'host' => $request->host(),
            'httpHost' => $request->httpHost(),
            'schemeAndHttpHost' => $request->schemeAndHttpHost(),
            'method' => $request->method(),
            'isMethod_post' => $request->isMethod('post'),
            'ip' => $request->ip(),
            'header_user_agent' => $request->header('User-Agent'),
            'has_header_accept' => $request->hasHeader('Accept'),
            'bearer_token' => $request->bearerToken() ?: 'aucun',
            'accepts_html' => $request->accepts('text/html'),
            'accepts_json' => $request->accepts('application/json'),
            'prefers' => $request->prefers(['text/html', 'application/json']),
            'expectsJson' => $request->expectsJson(),
            'all_input' => $request->all(),
            'collect_input' => $request->collect()->toArray(),
            'input_name' => $request->input('name', 'Inconnu'),
            'query_name' => $request->query('name', 'Pas dans query'),
            'boolean_archived' => $request->boolean('archived'),
            'date_birthday' => $request->date('birthday'),
            'dynamic_property' => $request->name ?? 'non défini',
            'only_username_email' => $request->only(['username', 'email']),
            'except_password' => $request->except(['password']),
            'has_name' => $request->has('name'),
            'hasAny_name_email' => $request->hasAny(['name', 'email']),
            'filled_email' => $request->filled('email'),
            'missing_phone' => $request->missing('phone'),
            'cookie_test' => $request->cookie('test_cookie', 'default'),
            'has_file_photo' => $request->hasFile('photo'),
        ], 200, [], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    }
    public function testPath(Request $request)
    {
        return "Path: " . $request->path() . "<br>" .
            "Est admin ? " . ($request->is('admin/*') ? 'Oui' : 'Non') . "<br>" .
            "Route nommée admin ? " . ($request->routeIs('admin.*') ? 'Oui' : 'Non');
    }

    public function testIsAdmin()
    {
        return "Tu es bien sur une route admin !";
    }
    public function testUrl(Request $request)
    {
        return view('test-url', compact('request'));
    }
    public function testMethod(Request $request)
    {
        return "Méthode : " . $request->method() .
            "<br>Est POST ? " . ($request->isMethod('post') ? 'Oui' : 'Non');
    }
    public function testInput(Request $request)
    {
        return response()->json([
            'all()' => $request->all(),
            'collect()' => $request->collect()->toArray(),
            'input("name")' => $request->input('name'),
            'input("name", "default")' => $request->input('name', 'Jean'),
            'query("search")' => $request->query('search', 'rien'),
            'boolean("active")' => $request->boolean('active'),
            'date("created_at")' => $request->date('created_at'),
            'only' => $request->only(['name', 'email']),
            'except' => $request->except(['password']),
            'has' => $request->has(['name', 'email']),
            'filled' => $request->filled('email'),
            'whenHas' => $request->whenHas('name', fn($n) => "Bonjour $n", fn() => "Pas de nom"),
        ], 200, [], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    }
    public function testOldInputForm()
    {
        return view('old-input-form');
    }

    public function testOldInputPost(Request $request)
    {
        // Simule une erreur de validation
        $request->flash(); // ou $request->flashExcept('password');

        return redirect('/test/old-input')->withInput();
    }
    public function testCookie(Request $request)
    {
        $value = $request->cookie('test_cookie');

        // Ajoute un cookie pour le prochain test
        return response("Cookie actuel : $value")
            ->cookie('test_cookie', 'valeur-secrète-123', 60);
    }
    public function uploadform()
    {
        return view('upload');
    }
    public function storefile(Request $request)
    {
        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $originalName = $file->getClientOriginalName();
            $newName = $request->name . '.' . $file->getExtension(); // if we want to use the new name
            $size = $file->getSize();
            $mimeType = $file->getMimeType();

            // Ensure the directory exists
            $destination = public_path('uploads');
            if (!file_exists($destination)) {
                mkdir($destination, 0755, true);
            }

            // Move the file and get the full path as string
            $file->move($destination, $originalName);
            $fullPath = 'uploads/' . $originalName; // This is the public URL path
            // Or absolute path: $fullPath = public_path('uploads/' . $originalName);

            return redirect('/test/upload-success')->with('fileInfo', [
                'originalName' => $originalName,
                'size'         => $size,
                'mimeType'     => $mimeType,
                'path'         => $fullPath,           // ← now a string!
                'url'          => asset($fullPath),    // convenient URL to display the image
            ]);
        }

        return back()->with('error', 'Aucun fichier téléchargé.');
    }
    public function uploadSuccess(Request $request)
    {
        $fileInfo = $request->session()->get('fileInfo');

        if ($fileInfo) {
            return view('view', compact('fileInfo'));
        } else {
            return redirect('/test/upload');
        }
    }
    //downloadfile
    public function downloadFile($filename)
    {
        // Build the correct absolute path in public/uploads
        $filePath = public_path('uploads/' . $filename);

        // Optional: sanitize filename if needed (security)
        $filename = basename($filename); // prevents directory traversal

        $filePath = public_path('uploads/' . $filename);

        if (!file_exists($filePath)) {
            abort(404, 'Fichier non trouvé.');
        }

        // Force download with original filename
        return response()->download($filePath, $filename);
    }
}
