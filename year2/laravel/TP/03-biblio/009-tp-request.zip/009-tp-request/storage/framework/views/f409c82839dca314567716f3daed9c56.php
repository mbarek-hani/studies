<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>

    <div>
        <img src="<?php echo e(asset($fileInfo['path'])); ?>" alt="Uploaded Image" style="max-width: 100%; height: auto;">
        <br>
        <a href="<?php echo e(route('download.file', $fileInfo['path'])); ?>">
            <button>Download</button>
        </a>
    </div>
</body>

</html>
<?php /**PATH C:\Users\Boubaker\ProjetsBackEnd\009-tp-request\resources\views/view.blade.php ENDPATH**/ ?>