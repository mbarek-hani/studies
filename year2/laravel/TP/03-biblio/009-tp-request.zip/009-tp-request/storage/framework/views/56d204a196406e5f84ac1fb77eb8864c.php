<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <style>
        .submit {
            background-color: #90EE90;
            /* Light Green */
            border: none;
            color: white;
            padding: 15px 32px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 4px 2px;
            cursor: pointer;
            border-radius: 8px;
            transition: background-color 0.3s ease;
        }

        .submit:hover {
            background-color: #76C76B;
            /* Darker Light Green */
        }
    </style>
    <title>Formulaire</title>
</head>

<body>
    <form method="POST" action="/test/old-input" class="max-w-md mx-auto p-4 bg-white shadow-md rounded">
        <?php echo csrf_field(); ?>
        <div class="mb-4">
            <label class="block text-gray-700 font-bold mb-2">Nom d'utilisateur:</label>
            <input type="text" name="username" value="<?php echo e(old('username')); ?>"
                class="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500">
        </div>
        <div class="mb-4">
            <label class="block text-gray-700 font-bold mb-2">Adresse e-mail:</label>
            <input type="email" name="email" value="<?php echo e(old('email')); ?>"
                class="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500">
        </div>
        <button type="submit" class="submit w-full py-2 px-4 rounded">Envoyer</button>
    </form>
</body>

</html>
<?php /**PATH C:\Users\Boubaker\ProjetsBackEnd\009-tp-request\resources\views/old-input-form.blade.php ENDPATH**/ ?>