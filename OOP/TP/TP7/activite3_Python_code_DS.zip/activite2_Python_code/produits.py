from abc import ABC, abstractmethod

class Composition:
    def __init__(self, produit, quantite):
        self.__produit = produit
        self.__quantite = quantite

    @property
    def produit(self):
        return self.__produit
    
    @produit.setter
    def produit(self, value):
        self.__produit = value

    @property
    def quantite(self):
        return self.__quantite
    
    @quantite.setter
    def quantite(self, value):
        self.__quantite = value

class Produit(ABC):
    def __init__(self, nom, code):
        self.__nom = nom
        self.__code = code

    @property
    def nom(self):
        return self.__nom
    
    @property
    def code(self):
        return self.__code
    
    @abstractmethod
    def getPrixHT(self):
        pass

class ProduitElementaire(Produit):
    def __init__(self, nom, code, prix_a):
        super().__init__(nom, code)
        self.__prix_achat = prix_a

    def __str__(self):
        return f"les information de ce produit est: \nnome : {self.nom} \ncode : {self.code} \nprix d'achat : {self.__prix_achat}\n"

    def getPrixHT(self):
        return self.__prix_achat  

class ProduitCompose(Produit):   
    tauxTVA = 0.18
    def __init__(self, nom, code, fraisFabrication, listeConstituations):
        super().__init__(nom, code)
        self.__fraisFabrication = fraisFabrication
        self.__listeConstituations = listeConstituations

    @property
    def fraisFabrication(self):
        return self.__fraisFabrication
    
    @property
    def listeConstituations(self):
        return self.__listeConstituations
    
    def  getPrixHT(self):
        # total = self.__fraisFabrication + sum([comp.produit.getPrixHT() * comp.quantite for comp in self.__listeConstituations])
        sume = self.__fraisFabrication
        for comp in self.__listeConstituations:
            sume += comp.produit.getPrixHT() * comp.quantite
        return sume 

    def __str__(self):
        compstr = "\n".join([f"{comp.produit} : {comp.quantite}" for comp in self.__listeConstituations])
        return f"les information de ce produit est: \nnome : {self.nom} \ncode : {self.code} \nles frais de fabrication : {self.__fraisFabrication}\nla liste de constituation:\n{compstr}" 
    


        
    
    

    
    