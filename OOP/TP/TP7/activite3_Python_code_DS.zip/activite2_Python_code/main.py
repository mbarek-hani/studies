from produits import *

if __name__ == "__main__":
    # test objets (constructeur)
    print("test objets (constructeur) ")

    p1 = ProduitElementaire("p1", "001", 10)
    p2 = ProduitElementaire("p2", "002", 13)
    copm1 = Composition(p1, 2)
    comp2 = Composition(p2, 6)
    p3 = ProduitCompose("p3", "003", 5, [copm1, comp2])

    # p4 = Produit("P4", "004")

    # test getter et setter
    print("test getter et setter")

    print(p1.nom)

    # p1.nom = "P8"
    # print(p1.nom)
    print("test du getter et setter de Composition")
    print(copm1.quantite)
    copm1.quantite = 6
    print(copm1.quantite)
    
    # teste de methode __str__
    print("teste de methode __str__")
    
    print("test de la methode __str__ de ProduitElementaire")
    print(p1)
    # print(copm1)
    print("test de la methode __str__ de ProduitCompose")
    print(p3)

    # teste des autre methodes
    print("teste des autre methodes")
    
    print("test de la methode getPrixHT de ProduitElementaire")
    print("p1.getPrixHT() = ", p1.getPrixHT())
    print("test de la methode getPrixHT de ProduitCompose")
    print("p3.getPrixHT() = ", p3.getPrixHT())





    




     